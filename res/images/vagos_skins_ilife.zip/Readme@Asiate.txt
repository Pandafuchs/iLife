vla2.png 
Los Santos Vagos
Skin ID: 115
Skin Model Name: vla2

vla3.png
Los Santos Vagos
Skin ID: 116
Skin Model Name: vla3